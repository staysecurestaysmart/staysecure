﻿Imports System.Net

Public Class Form1


    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Form2.Show()
    End Sub
    Dim notice(1000) As String
    Dim i As Integer = 1
    Dim TempPath As String = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) & "\Temp"
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ''''''' added to startup
        If My.Computer.Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True).GetValue(Application.ProductName, Nothing) Is Nothing Then
            My.Computer.Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True).SetValue(Application.ProductName, Application.ExecutablePath)

        End If
        'remove startup
        'My.Computer.Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True).DeleteValue(Application.ProductName)

2:
        ''check internet and download latest stips.txt
        If My.Computer.Network.IsAvailable Then
            My.Computer.Network.DownloadFile("http://mycityplace.in/sssstips/stips.txt", "c:\windows\stips.txt", userName:=String.Empty, password:=String.Empty, showUI:=False, connectionTimeout:=1000000, overwrite:=True)
            'My.Computer.Network.DownloadFile("http://localhost:40/test/stips.txt", "c:\windows\stips.txt", userName:=String.Empty, password:=String.Empty, showUI:=False, connectionTimeout:=1000000, overwrite:=True)
        End If

        Dim FILE_NAME As String = "c:/windows/stips.txt"

        If System.IO.File.Exists(FILE_NAME) = True Then

            Dim objReader As New System.IO.StreamReader(FILE_NAME)



            Do While objReader.Peek() <> -1

                notice(i) = objReader.ReadLine()
                i += 1
            Loop

            Label1.Text = notice(1)

        Else

            MessageBox.Show("Please Connect to the Internet")
            Me.Close()

        End If
    End Sub

    Dim k As Integer = 1


    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        If k < i Then
            Label1.Text = notice(k)
        End If
        k += 1
        If k = i Then
            k = 1
        End If
    End Sub






    Private Sub PauseNotifyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PauseNotifyToolStripMenuItem.Click
        Form2.Close()
        Timer1.Enabled = False
    End Sub

    Private Sub StartNotifyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartNotifyToolStripMenuItem.Click
        Form2.Show()
        Timer1.Enabled = True
    End Sub

    

    Private Sub NoStartupToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        My.Computer.Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True).DeleteValue(Application.ProductName)
    End Sub



    Private Sub NotifyIcon1_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles NotifyIcon1.MouseDoubleClick

    End Sub

    Private Sub UpdateToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateToolStripMenuItem.Click
        If My.Computer.Network.IsAvailable Then
            My.Computer.Network.DownloadFile("http://mycityplace.in/sssstips/stips.txt", "c:\windows\stips.txt", userName:=String.Empty, password:=String.Empty, showUI:=False, connectionTimeout:=1000000, overwrite:=True)
            'My.Computer.Network.DownloadFile("http://localhost:40/test/stips.txt", "c:\windows\stips.txt", userName:=String.Empty, password:=String.Empty, showUI:=False, connectionTimeout:=1000000, overwrite:=True)


            '''''load tips in array
            Dim FILE_NAME As String = "c:/windows/stips.txt"

            If System.IO.File.Exists(FILE_NAME) = True Then
                Dim objReader As New System.IO.StreamReader(FILE_NAME)
                Do While objReader.Peek() <> -1
                    notice(i) = objReader.ReadLine()
                    i += 1
                Loop
                Label1.Text = notice(1)
            Else
                MessageBox.Show("Please connect to the Internet")
                Me.Close()
            End If
            '''''''''''''''''''
            MsgBox("Update Completed.", MsgBoxStyle.Exclamation, "Update Success")
        Else
            MsgBox("Please connect to the Internet", MsgBoxStyle.Exclamation, "Update Failed.")
        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub
End Class
